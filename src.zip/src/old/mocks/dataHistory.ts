export const dataTimePost = [
    {
        name: '30 phút',
        time: '30m'
    },
    {
        name: '60 phút',
        time: '1h'
    },
    {
        name: '3 tiếng',
        time: '3h'
    },
    {
        name: '1 ngày',
        time: '1d'
    },
    {
        name: '3 ngày',
        time: '3d'
    },
    {
        name: '7 ngày',
        time: '7d'
    },
    {
        name: '15 ngày',
        time: '15d'
    },
    {
        name: '30 ngày',
        time: '30d'
    }
];
export const dataTimeEmerency = [
    {
        name: '3 ngày',
        time: '3d'
    },
    {
        name: '15 ngày',
        time: '15d'
    },
    {
        name: '30 ngày',
        time: '35d'
    },
    {
        name: '60 ngày',
        time: '60d'
    }
]
// 30p = 30m
// 60p = 1h
// 1ngay bang 1d