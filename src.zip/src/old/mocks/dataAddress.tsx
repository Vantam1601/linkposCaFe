export const dataConscious = [
  {
    name: "An Giang",
    id: "89"
  },
  {
    name: "Bình Dương",
    id: "74"
  },
  {
    name: "Gia Lai",
    id: "64"
  },
]