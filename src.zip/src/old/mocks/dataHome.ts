export const dataQuestion = [
  {
    title: "1. KBNC là gì?",
    content:
      "KNC là kênh kết nối nhu cầu bên mua - bên bán. \nĐồng thời là kênh kết nối các dịch vụ và chương trình liên kết với tất cả cửa hàng.",
  },
  {
    title: "2. Chương trình đổi quà như thế nào?",
    content:
      "- Người dùng nhận thưởng từ Chương trình tặng thưởng – đổi quà hàng tuần. Khi ngừoi dùng đạt hơn 100,000(điểm) có thể qui ra món quà từ hệ thống. \n  - Ngoài ra, khi bạn được quà chương trình công ty sẽ gởi món quà đến địa chỉ tương ứng với địa chỉ mà bạn đã đăng ký.",
  },
  {
    title: "3. Tôi tích luỹ điểm như thế nào?",
    content:
      "Bạn có thể tích luỹ điểm theo các phương thức:  \n  - Giới thiệu bạn bè.  \n  - Tham gia chương trình vòng quay may mắn.  \n  - Đăng bài, dánh giá bài viết.",
  },
  {
    title: "4. Ví KNC là gì?",
    content: "",
  },
  {
    title: "5. Nạp vào ví KNC như thế nào?",
    content: "",
  },
  {
    title: "6. Tạo sao tài khoản của tôi không hoạt động?",
    content: "",
  },
  {
    title: "7. Tôi có thể đăng ký cửa hàng lên KNC như thế nào?",
    content: "",
  },
  {
    title: "8. Làm thế nào phân biệt ngắn hạn và dài hạn?",
    content: "",
  },
];
