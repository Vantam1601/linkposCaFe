import React, { memo, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import {
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";

import { AppText } from "src/components/Apptext";
import HeaderBack from "src/components/HeaderBack";
import { useTranslate } from "src/hooks/useTranslate";
import { COLOR } from "src/theme/color";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { dataLoadPoint } from "src/old/mocks/dataWalletPoint";
import { amountFormat } from "src/helpers/constants";
import { TouchableOpacity } from "react-native-gesture-handler";
import RadioButton from "src/components/RadioButton";
import Button from "src/components/Button";
import { useNavigation } from "@react-navigation/native";
import { AppRoutes } from "src/navigator/app-routes";
import { useTypedDispatch } from "src/hooks/useTypedDispatch";
import {
  postContinueWithdrawBankAction,
  postContinueWithdrawMomoAction,
} from "src/old/stores/app/app.actions";
import Input from "src/components/AppInputElement";
import { useTypedSelector } from "src/hooks/useTypedSelector";

const LoadPointSchema = Yup.object().shape({
  money: Yup.string().required("* Required"),
});
type LoadPointMutationVariables = {
  money: string;
};

const { width } = Dimensions.get("window");

const WithdrawPointsScreen = memo((navigationRoute: any) => {
  const { route } = navigationRoute;
  const params = route?.params;

  const [selectBank, setSelectBank] = useState<number>(0);
  const [bank, setBank] = useState<string>("bank");
  const [money, setMoney] = useState<string>(
    params?.intPoint ? params?.intPoint.toString() : ""
  );
  const [isIndex, setIsIndex] = useState<number>(-1);
  const [loading, setLoading] = useState<boolean>(false);

  const intl = useTranslate();
  const navigation = useNavigation();
  const dispatch = useTypedDispatch();

  const config: any = useTypedSelector((state) => state.app.appJson);

  const { control, handleSubmit, errors } = useForm<LoadPointMutationVariables>(
    {
      resolver: yupResolver(LoadPointSchema),
    }
  );

  const onSelectBank = (type: any) => {
    let bank = "";
    if (type === 0) {
      bank = "bank";
      setSelectBank(type);
    } else if (type === 1) {
      bank = "paypal";
      setSelectBank(type);
    } else {
      bank = "momo";
      setSelectBank(type);
    }
    setBank(bank);
  };
  const onSelectMoney = (value: string, index: any) => {
    if (value === "label:others") {
      setMoney("");
      setIsIndex(index);
    } else {
      setMoney(value);
      setIsIndex(index);
    }
  };
  const onContinue = async () => {
    if (loading) {
      return;
    }
    setLoading(true);
    let result: any;
    if (bank === "bank") {
      result = await dispatch(postContinueWithdrawBankAction());
    } else if (bank === "momo") {
      result = await dispatch(postContinueWithdrawMomoAction());
    }
    setLoading(false);
    if (result && result.data) {
      navigation.navigate(AppRoutes.TRANSFER_PAYMENTS, {
        value: result?.data,
        money,
        bank,
      });
    }
  };
  const onChangeMoney = (txt: string) => {
    setMoney(txt);
  };
  return (
    <View style={styles.container}>
      <SafeAreaView />
      <SafeAreaView style={{ backgroundColor: COLOR.contentColor, flex: 1 }}>
        <HeaderBack title={"label:withdraw_point"} />
        <KeyboardAvoidingView
          style={{
            flex: 1,
            justifyContent: "center",

            alignItems: "center",
          }}
          enabled
          keyboardVerticalOffset={50}
          behavior={Platform.OS !== "android" ? "padding" : "height"}
        >
          <ScrollView
            style={{ backgroundColor: COLOR.contentColor, flex: 1 }}
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.vMain}>
              <AppText style={styles.txtLabel}>
                {intl.formatMessage({
                  id: "label:score",
                })}{" "}
                *
              </AppText>
              <Controller
                control={control}
                render={({ onChange, onBlur, value }) => (
                  <Input
                    autoFocus
                    autoCapitalize="none"
                    placeholder={intl.formatMessage({
                      id: "input:input_score",
                    })}
                    errorStyle={styles.textError}
                    errorMessage={
                      errors.money && money === "" ? errors.money.message : ""
                    }
                    multiline={false}
                    onChangeText={(val: string) => {
                      onChangeMoney(val);
                      onChange(val);
                    }}
                    onBlur={onBlur}
                    value={money}
                    containerStyle={[
                      styles.input,
                      { marginBottom: errors.money && money === "" ? 50 : 16 },
                    ]}
                    style={styles.textInput}
                  />
                )}
                name="money"
                rules={{ required: true }}
                defaultValue=""
              />
              <View
                style={{
                  flexDirection: "row",
                  flexWrap: "wrap",
                  paddingHorizontal: 10,
                  // justifyContent: "center",
                }}
              >
                {dataLoadPoint?.map((item: any, index: number) => (
                  <TouchableOpacity
                    activeOpacity={0.7}
                    key={index}
                    onPress={() => onSelectMoney(item, index)}
                    style={[
                      styles.vItemMoney,
                      {
                        backgroundColor:
                          isIndex === index
                            ? COLOR.bgBlue_bland
                            : COLOR.contentColor,
                      },
                    ]}
                  >
                    <AppText style={styles.txtMoney}>
                      {intl.formatMessage({
                        id: item,
                      })}
                      {index != 4}
                    </AppText>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            <View style={styles.vTextNote}>
              <AppText fontSize={15}>
                {intl.formatMessage({
                  id: "label:note",
                })}
              </AppText>
            </View>
            <View style={[styles.vMain, { paddingHorizontal: 10 }]}>
              <AppText style={styles.txtMoney}>
                {intl.formatMessage({
                  id: "translation:minimum_to_withdraw",
                })}{" "}
                <AppText style={styles.txtMoney} fontWeight={"600"}>
                  {config?.wallet?config.wallet.point.withdraw.min:"100,000"}
                </AppText>{" "}
                {intl.formatMessage({
                  id: "label:point",
                })}
              </AppText>
              <AppText style={styles.txtMoney}>
                {config?.wallet?config.wallet.point.withdraw.rate:""}
              </AppText>
            </View>
            <View style={styles.vTextNote}>
              <AppText fontSize={15}>
                {intl.formatMessage({
                  id: "translation:select_bank_account",
                })}
              </AppText>
            </View>
            <View
              style={[
                styles.vMain,
                { paddingHorizontal: 5, paddingVertical: 8 },
              ]}
            >
              <RadioButton
                titleRight={"translation:transfer_payments"}
                onPress={onSelectBank}
                type={0}
                stylesProps={selectBank == 0 ? COLOR.light_blue : "gray"}
              />
              <RadioButton
                titleRight={"translation:payment_paypal"}
                onPress={onSelectBank}
                type={1}
                stylesProps={selectBank == 1 ? COLOR.light_blue : "gray"}
              />
              <RadioButton
                titleRight={"translation:payment_momo"}
                onPress={onSelectBank}
                type={2}
                stylesProps={selectBank == 2 ? COLOR.light_blue : "gray"}
              />
            </View>
            <View style={[styles.vMain, styles.vBottom]}>
              <Button
                buttonStyle={styles.buttonLogin}
                onPress={() => onContinue()}
                loading={loading}
                text={intl.formatMessage({
                  id: "label:continue",
                })}
                loadingColor={COLOR.white}
                textStyle={styles.txtVerify}
              />
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLOR.main_color,
  },
  vMain: {
    marginHorizontal: 12,
    ...Platform.select({
      ios: {
        shadowColor: COLOR.shadow,
        shadowOffset: {
          height: 1,
          width: 0,
        },
        shadowRadius: 2,
        shadowOpacity: 0.22,
      },
      android: {
        elevation: 10,
      },
    }),
    paddingVertical: 12,
    backgroundColor: COLOR.bgWhite,
    margin: 12,
    marginBottom: 0,
    borderRadius: 6,
  },
  vBottom: {
    paddingVertical: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  txtTitle: {
    marginTop: 5,
    marginBottom: 10,
    textAlign: "center",
  },
  textError: {
    position: "absolute",
    color: COLOR.error,
    marginTop: 10,
    marginBottom: 5,
    textAlign: "right",
    bottom: -40,
    right: 0,
  },
  input: {
    width: width - 30,
    height: 35,
    backgroundColor: COLOR.white,
    textAlignVertical: "center",
  },
  textInput: {
    fontSize: 13,
    fontFamily: "Inter-Regular",
  },
  txtLabel: {
    fontSize: 13,
    textAlignVertical: "center",
    fontWeight: "600",
    marginLeft: 10,
    marginTop: 10,
  },
  txtMoney: {
    fontSize: 15,
    textAlignVertical: "center",
  },
  vItemMoney: {
    height: 62,
    paddingHorizontal: 20,
    borderRadius: 6,
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 5,
    marginTop: 5,
    borderColor: COLOR.borderWhiteGray,
  },
  buttonLogin: {
    width: width - 60,
  },
  txtVerify: {
    fontWeight: "bold",
    fontSize: 14,
    color: COLOR.white,
  },
  vTextNote: {
    marginHorizontal: 12,
    borderLeftWidth: 5,
    borderLeftColor: COLOR.bgDark_blue,
    paddingHorizontal: 7,
    marginTop: 15,
  },
});

export default WithdrawPointsScreen;
