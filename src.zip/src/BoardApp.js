 
import React, { useEffect,useState } from 'react';
 
import { LogBox, Text,Platform,ActivityIndicator,View,} from 'react-native';
 
import { i18n } from './src/locales';
 
 
import { useNavigation } from "@react-navigation/native";
 
 

const BoardApp = ({navigation, route}) => {

 
useEffect(() => {
    
}, []);

 
  return (
    <View>
      
    </View>
  );
};

export default BoardApp;
