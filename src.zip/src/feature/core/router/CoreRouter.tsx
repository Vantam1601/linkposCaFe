export enum coreRoutes {
  //AUTH
  MY_STORE = "MyStore",
  CAFE = "Cafe",
  DASH_BOARD = "Dashboard",
  RegisterStepOne = "RegisterStepOne",
  RegisterStepTwo = "RegisterStepTwo",
  RegisterStepThree = "RegisterStepThree",
  ChooseShop = "ChooseShop",
  Profile = "Profile",
  InfoProfile = "InfoProfile",
}
