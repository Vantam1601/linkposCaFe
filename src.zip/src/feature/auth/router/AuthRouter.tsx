export enum authRoutes {
  //AUTH
  LOGIN = "Login",
  REGISTER = "Register",
  VERIFY_PASSS = "verifyPassword",
  FORGOT_PASSWORD = "ForgotPassword",
  FORGOT_PASSWORD_OTP = "ForgotPasswordOTP",
  FORGOT_PASSWORD_OTP_NEW = "ForgotPasswordOTPNEW",
  UPDATE_PASSWORD = "Update_Password",
}
